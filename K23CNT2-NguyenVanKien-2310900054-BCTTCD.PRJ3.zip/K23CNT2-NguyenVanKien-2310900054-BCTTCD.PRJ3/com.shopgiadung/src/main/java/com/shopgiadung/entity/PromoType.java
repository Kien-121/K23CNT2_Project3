package com.shopgiadung.entity;

public enum PromoType {
    PERCENT, // Giảm theo phần trăm (ví dụ 10%)
    FIXED    // Giảm số tiền cố định (ví dụ 50.000đ)
}