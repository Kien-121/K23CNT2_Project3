package com.shopgiadung.entity;

public enum NvkRole {
    CUSTOMER,
    ADMIN,
    STAFF
}